
struct detection{

highp float day;
highp float night;
highp float dusk;
highp float rain;
highp float cave;
highp float morning;
highp float midnight;

}at;

struct COLORING{

highp float DirlightX;
highp float Distpos;
highp vec3 inWorld;
highp vec3 inNether;
highp vec3 inTheEnd;
highp vec3 Water;
highp vec3 Shadows;
highp vec3 Grayscale;
highp vec3 Grass;
highp vec3 underWater;
highp vec3 Leaves;
highp vec3 Exposure;
highp vec3 Torch;
highp vec3 SeaLantern;
highp vec3 DirlightZ;

}clr;

struct FOGGY{

highp float Atmosphere;
highp float foggyRain;
highp float foggyDusk;
highp float foggyNight;
highp vec3 AtmosphereON;
highp vec3 foggyRainON;
highp vec3 foggyDuskON;
highp vec3 foggyNightON;

}fog;
