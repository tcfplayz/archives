#define ON true
#define OFF false
#define sba abs
#define time TIME*.2
#define end return
#define col1 clamp
#define sabun length
#define slap pow
#define tod dot
#define xim mix
#define xam max
#define nim min
#define v2 vec2
#define v3 vec3
#define v4 vec4
#define tau 7.
#define ddx dFdx
#define ddy dFdy
#define frac fract
//#define DEBUG
/*
▒▒▒▒▒▒▒▓
▒▒▒▒▒▒▒▓▓▓
▒▓▓▓▓▓▓░░░▓
▒▓░░░░▓░░░░▓
▓░░░░░░▓░▓░▓
▓░░░░░░▓░░░▓
▓░░▓░░░▓▓▓▓                            "Hey, what are
▒▓░░░░▓▒▒▒▒▓                      you doing in here??:*"
▒▒▓▓▓▓▒▒▒▒▒▓
▒▒▒▒▒▒▒▒▓▓▓▓
▒▒▒▒▒▓▓▓▒▒▒▒▓
▒▒▒▒▓▒▒▒▒▒▒▒▒▓
▒▒▒▓▒▒▒▒▒▒▒▒▒▓    
▒▒▓▒▒▒▒▒▒▒▒▒▒▒▓
▒▓▒▓▒▒▒▒▒▒▒▒▒▓
▒▓▒▓▓▓▓▓▓▓▓▓▓
▒▓▒▒▒▒▒▒▒▓
▒▒▓▒▒▒▒▒▓
*/