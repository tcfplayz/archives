highp float rayPos(in vec3 pos, float yPos){
highp vec3 np = normalize(pos);
highp float sun = abs(1.-length(np.yz));
highp vec3 Pos = vec3(smoothstep((8.5-yPos) + abs(np.y)*2.4,0.,abs(np.z)*1.7));
highp vec3 flatRange = vec3(max(0.,sun));
return pow(max(dot(Pos, flatRange), 0.0),5.0);}
highp vec3 raySun(in vec3 pos, vec3 x){
highp float specularFlat = rayPos(pos,1.4);
x *= vec3(1.2,1.,.0)*specularFlat;
return x;}
float W = 2.6;
float A = .0;
float N = .2*1.;
float Z = .75*1.;
float E = .1;
float S =.5;
highp vec3 HSTM(vec3 x){
return ((x*(W*x+N*A)+Z*E)/(x*(W*x+A)+Z*S))-E/S;}
highp vec3 HSS(vec3 rgb, float adjustment){ 
const vec3 W = vec3(0.2125, 0.7154, 0.0721); 
vec3 intensity = vec3(dot(rgb, W)); 
return mix(intensity, rgb, adjustment);}