
/*
please permission first.
before you used this code:)
twitter : @DevHSPE
*/

highp vec3 HSTM(vec3 x){
float W = 2.6;
float A = .0;
float N = .2*1.;
float Z = .75*1.;
float E = .1;
float S =.5;
return ((x*(W*x+N*A)+Z*E)/(x*(W*x+A)+Z*S))-E/S;}

highp vec3 HSS(vec3 rgb, float adjustment){ 
const vec3 W = vec3(.2125, .7154, .0721); 
vec3 intensity = vec3(dot(rgb, W)); 
return mix(intensity, rgb, adjustment);}
