
/*
please permission first.
before you used this code:)
twitter : @DevHSPE
*/

#include "setHSPE/tonemap.h"

//World Color
highp vec3 clrWorld(highp vec3 clrW, detection at){
clrW = mix(vec3(1.7),vec3(1.2,1.15,1.1), at.day);
clrW = mix(clrW, vec3(.1,-1.,-5.), at.dusk);
clrW = mix(clrW, vec3(2.5), at.rain);
clrW = mix(clrW, vec3(2.,2.,4.5), at.night);
clrW = mix(clrW,vec3(1.), at.cave);
return clrW;}

//Water Color
highp vec3 clrWater(highp vec3 clrWtr, detection at){
clrWtr = mix(vec3(.0,.535,.9), vec3(.0,.3,.7), at.dusk);
clrWtr = mix(clrWtr, vec3(.0, .3, .8), at.rain);
clrWtr = mix(clrWtr, vec3(.05, .15, .5), at.night);
clrWtr = mix(clrWtr, vec3(.0,.1,.2), at.cave);
return clrWtr;}

//Torch Color
highp vec3 light(vec3 result,other clr,float shx,  detection at){
float nolight; 
float lightUp;
nolight = mix(1.,.35,at.day);
nolight = mix(nolight,1.1,at.cave);
nolight = mix(nolight,1.8,at.night);
nolight = mix(nolight, 1.5, at.rain);
lightUp = pow(shx*.92,2.7);
clr.Torch = vec3(1.5,.2,-.8);
result = clr.Torch*nolight*lightUp;
return result;}

//Shadow
highp vec3 shadow(vec3 shd, other clr, float shside, float shy){
if((.867>shy)||(.604>shside)){
shd.rgb *= clr.Shadows;}
if((.868>shy)||(.608>shside)){
shd.rgb *= clr.Shadows;}
if((.869>shy)||(.6012>shside)){
shd.rgb *= clr.Shadows;}
if((.87>shy)||(.616>shside)){
shd.rgb *= clr.Shadows;}
if((.871>shy)||(.62>shside)){
shd.rgb *= clr.Shadows;}
if((.872>shy)||(.624>shside)){
shd.rgb *= clr.Shadows;}
if((.873>shy)||(.628>shside)){
shd.rgb *= clr.Shadows;}
if((.874>shy)||(.632>shside)){
shd.rgb *= clr.Shadows;}
return shd;}

//Raysun
highp float rayPos(in vec3 pos, float yPos){
highp vec3 np = normalize(pos);
highp float sun = abs(1.-length(np.yz));
highp vec3 Pos = vec3(smoothstep((8.5-yPos) + abs(np.y)*2.4,0.,abs(np.z)*1.7));
highp vec3 flatRange = vec3(max(0.,sun));
return pow(max(dot(Pos, flatRange), 0.0),5.0);}
highp vec3 raySun(in vec3 pos, vec3 x){
highp float specularFlat = rayPos(pos,1.4);
x *= vec3(1.2,1.,.0)*specularFlat;
return x;}

