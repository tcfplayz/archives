
struct detection{

float day;
float night;
float dusk;
float rain;
float cave;
float morning;
float sunset;
float midnight;

}at;

struct other{

highp float Distpos;
highp vec3 Shadows;
highp vec3 Grayscale[2];
highp vec3 Grass;
highp vec3 underWater;
highp vec3 Leaves;
highp vec3 Exposure;
highp vec3 Torch;
highp vec3 SeaLantern;
highp vec3 Dirlight[4];

}clr;

struct FOGGY{

 float Atmosphere;
 float foggyRain;
 float foggyDusk;
 float foggyNight;
 vec3 AtmosphereON;
 vec3 foggyRainON;
 vec3 foggyDuskON;
 vec3 foggyNightON;

}fog;

struct PS_input{

 vec4 wnz;
 vec4 tex;

}PSinput;

struct FOG{

 float fogDusk;
 vec3 fogDuskON;

}ground;
