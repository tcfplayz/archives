
#include "setHSPE/library.h"

mat2 makem2(in float theta){float c = cos(theta);float s = sin(theta);return mat2(c,-s,s,c);}
float hash( float n ){
return fract(sin(n)*43758.5453);}

highp float rand(highp vec2 p){ 
	return fract(cos(p.x +p.y * 335.0+sin(p.x*1.011+p.y*p.y)) * 735.552);}

highp float bnoise( highp vec2 p){
vec2 i = floor(p); 
vec2 f = fract(p); 
vec2 u = pow(f,vec2(2.))*(2. - 1.*f); 
float a = rand(i+vec2(0.,0.));
float b = rand(i+vec2(1.,0.));
float c = rand(i+vec2(0.,1.));
float d = rand(i+vec2(1.,1.));
float middle = mix(a, b, u.x);
float near = mix(c, d, u.x);
float volume = mix(middle, near, u.y);
return volume;}