#include "setHSPE/struct.h"

//please permission first.
//if you used this code:)
//twitter : @DevHSPE

//----terrain
  bool isWater(vec4 clr){
if((clr.b*2.0>clr.r+clr.g) || (clr.g < .39 && clr.g > .25 && clr.b < clr.g && clr.b < .35 && clr.b > .23 && clr.r < clr.g && clr.r < clr.b)){return true;}else{return false;}}
 bool isNether(vec4 fc){
if(fc.r > fc.b && fc.r < 0.5 && fc.b < .05){
return true;}else{return false;}}
  bool isTheEnd(vec4 fc){
if(fc.r > fc.g && fc.b > fc.g && fc.r < .05 && fc.b < .05 && fc.g < .05){
return true;}else{return false;}}
  bool isUnderwater(vec2 fcc, vec4 fc){
if(fcc.x == 0. && fc.b > fc.r){
return true;}else{return false;}}

//----metallic
  bool isGold(vec4 isBlock){
if(uvectorA(isBlock)){
return true;}else{return false;}}
   bool isDiamond(vec4 isBlock){
if(uvectorB(isBlock)){
return true;}else{return false;}}
   bool isEmerald(vec4 isBlock){
if(uvectorC(isBlock)){
return true;}else{return false;}}
   bool isIron(vec4 isBlock){
if(uvectorD(isBlock)){
return true;}else{return false;}}
   bool isRedstone(vec4 isBlock){
if(uvectorE(isBlock)){
return true;}else{return false;}}
   bool isLapisLazuli(vec4 isBlock){
if(uvectorF(isBlock)){
return true;}else{return false;}}

//----ores
  bool TEXTURE_3(PS_input PSinput){
if(uvectorG(PSinput.tex)){
return true;}else{return false;}}
  bool isDiamondOre(PS_input PSinput){
if(uvectorH(PSinput.wnz)){
return true;}else{return false;}}
  bool isEmeraldOre(PS_input PSinput){
if(uvectorI(PSinput.wnz)){
return true;}else{return false;}}
  bool isGoldOre(PS_input PSinput){
if(uvectorJ(PSinput.wnz)){
return true;}else{return false;}}
  bool isLapisOre(PS_input PSinput){
if(uvectorK(PSinput.wnz)){
return true;}else{return false;}}
  bool isIronOre(PS_input PSinput){
if(uvectorL(PSinput.wnz)){
return true;}else{return false;}}
bool isRedstoneOre(PS_input PSinput){
if(uvectorM(PSinput.wnz)){
return true;}else{return false;}}