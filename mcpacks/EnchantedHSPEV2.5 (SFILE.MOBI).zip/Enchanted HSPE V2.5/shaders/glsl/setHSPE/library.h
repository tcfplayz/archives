
const float ON = 1.0;
const float OFF = 0.0;

//---------for all .fsh
#define ddx dFdx
#define ddy dFdy
#define frac fract
#define float2 vec2
#define float3 vec3
#define float4 vec4
#define lerp mix

float maxA(float x){return max(0.,x);}
float clampA(float x){return clamp(x,0.,1.);}
float smoothstepA(float x){return smoothstep(0.,1.,x);}

//-------for experimental
uniform float UNIVERSAL_VECTOR;
uniform sampler2D METALLIC;

#define time TIME*.2
#define uvector(x) vec4(x,x)
#define RES 0.2
#define tau 6.3
#define uvectorA(x) (x.r<.93&&x.g<.32&&x.b<.93&&x.r>.9&&x.b>.9&&x.g >.28)
#define uvectorB(x) (x.r<.56&&x.g <.3&&x.b<.6&&x.r >.51&&x.b >.5&&x.g >.2)
#define uvectorC(x) (x.r <.024 && x.g <.32 && x.b <.025 &&x.g>.28&&x.r >.0078&&x.b >.0078)
#define uvectorD(x) (x.r <.37&&x.g <.38 &&x.b <.34 &&x.r >.3 &&x.g>.34 &&x.b>.3)
#define uvectorE(x) (x.r <.5 && x.g <.6 &&x.b <.5 &&x.r >.4 && x.g >.5 &&x.b >.4)
#define uvectorF(x) (x.r <.78 &&x.g <.37 &&x.b<.8 &&x.r >.7 &&x.g >.34 &&x.b >.75)
#define uvectorG(x) (x.r <.561 && x.g <.567&&x.b <.564 &&x.r >.38 &&x.g >.4 && x.b >.35)
#define uvectorH(x) (x.r < .59 && x.g <.24 && x.b <.6 && x.r >.56 && x.g >.22 && x.b >.565)
#define uvectorI(x) (x.r <.06 && x.g <.31 && x.b <.06 && x.r >.02 && x.g >.29 && x.r > .04)
#define uvectorJ(x) (x.r <.97 && x.g <.32 && x.b <.98 && x.r>.93 && x.g >.28&& x.b >.94)
#define uvectorK(x) (x.r <.82 && x.g <.37 && x.b <.83 && x.r >.75 && x.g >.32 && x.b >.78)
#define uvectorL(x) (x.r <.37 && x.g <.37 && x.b <.37 && x.r >.35 && x.g >.35 &&x.b >.34)
#define uvectorM(x) (x.r <.59 && x.g <.54 && x.b <.6 && x.r >.57 && x.g >.5 && x.b >.55)

//------for endsky [default]
#define ARM_COUNT 5.
#define WHIRL 14.0

