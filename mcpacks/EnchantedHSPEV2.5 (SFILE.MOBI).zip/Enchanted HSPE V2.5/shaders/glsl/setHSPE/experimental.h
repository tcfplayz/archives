#include "setHSPE/noise.h"
#include "setHSPE/detection.h"

/*
please permission first.
before you used this code:)
twitter : @DevHSPE
*/

float beam(in vec2 p)
{
	vec2 p2 = p*.7;
	vec2 basis = vec2(bnoise(p2-time*4.6),bnoise(p2+time*1.7));
	basis = (basis-.5)*.2;
	p += basis;
	return bnoise(p*makem2(time*.2));
}

highp vec3 sunbeam(vec3 result, vec3 hsc, vec3 hswp, vec3 hsp,detection at){
vec3 beamC;
 vec2 beamPos;
  float beams1 = (2.*atan(.7));
   float beams2 = (beams1*beams1+2.);
 float beams3 = smoothstep(1.,.0,length(hsc.xy));
float beams4 = smoothstep(.0,.5,length(hswp.zy)*.03);
  beamC = vec3(1.,.5,.1);
 beamPos = vec2((atan(hswp.y/hswp.z)/beams2)*4.8, length(hsp.xz));
result=beam(vec2(beamPos.x*5.2))*beamC*beams3*beams4*at.dusk*at.morning*(1.-at.rain)*(1.-at.day);
return result;}

      highp float wet_wave(vec3 ps){
   float wave = pow(bnoise(vec2(ps.x+ps.z+ps.z+TIME*.35,ps.z+ps.x+ps.x+TIME*.28)*1.5),2.5); 
   wave = clamp(length(wave),0., 2.5);
     return wave;}
       highp float puddle(vec3 ps,vec3 dr ,detection at){
     float wet =  clamp(length(bnoise(ps.xz*.7))*.2,.0,2.);
    return wet*(1.-at.night)*at.rain*max(0., dr.y);}

               highp vec3 refleksi(vec3 pp, float shx){
                                       float ref[2];
                               vec3                  cref;
                                      ref[0] = 1.4;
                            ref[1] = bnoise(pp.xy*.7);
                                cref = vec3(1.5,.5,.1);
                         return ref[1]*cref*shx*ref[0];}
        highp float refleks(vec3 wp, vec3 R,detection at){
                                      float ref[3];
                              float            nolight[2];
                              vec3           ref_pos[2];
               nolight[0] = (1.-at.cave);
                      ref[0] = 1.;
                                                  ref[1] =.8;
                                           nolight[1] = (1.-at.rain);
           ref_pos[0] =               normalize(vec3(-2,05,0)-wp); 
          ref_pos[1] = reflect(-ref_pos[0], R);  
          ref[2] = pow(max(dot(ref_pos[1], R), 0.),5.);
      return ref[0]*ref[2]*ref[1]*nolight[0]*nolight[1]*.5;}


void _ores(inout vec3 HSdiff, PS_input PSinput, float shx,detection at){
float nolight = (1.-shx);
vec3 glow[2] = vec3[2](mix(vec3(1.), vec3(2.6),at.night),mix(vec3(1.),vec3(10.),at.cave));
  if(isDiamondOre(PSinput) || isEmeraldOre(PSinput)){
  if(!TEXTURE_3(PSinput)){
HSdiff.rgb *= glow[1]*1.5*nolight;
HSdiff.rgb *= glow[0]*1.2*nolight;}}
  if(isLapisOre(PSinput) || isRedstoneOre(PSinput)){
  if(!TEXTURE_3(PSinput)){
HSdiff.rgb *= glow[1]*2.*nolight;
HSdiff.rgb *= glow[0]*1.5*nolight;}}
  if(isIronOre(PSinput) || isGoldOre(PSinput)){
  if(!TEXTURE_3(PSinput)){
HSdiff.rgb *= glow[1]*1.3*nolight;
HSdiff.rgb *= glow[0]*nolight;}}}

void _metallic(inout vec3 HSdiff, vec4 wnz, float ref_b,detection at){
float thick[4];
thick[0] = mix(1.,.4,at.day);
thick[1] = mix(1.,.5,at.day);
thick[2] = mix(1.,1.3,at.day);
thick[3] = mix(1.,.3, at.day);
if(isGold(wnz) || isIron(wnz)){
HSdiff.rgb += ref_b*1.4*thick[3];}
if(isEmerald(wnz)){
HSdiff.rgb += ref_b*1.15*thick[1];}
if(isDiamond(wnz) || isRedstone(wnz)){
HSdiff.rgb += ref_b*1.1*thick[0];} 
if(isLapisLazuli(wnz)){ 
HSdiff.rgb += ref_b*1.3*thick[2];}}

