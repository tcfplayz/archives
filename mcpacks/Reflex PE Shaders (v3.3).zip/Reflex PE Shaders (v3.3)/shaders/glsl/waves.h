#ifndef WAVES_H_INCLUDED
#define WAVES_H_INCLUDED

#define LEAVES_WAVES
#define WATER_WAVES

#endif